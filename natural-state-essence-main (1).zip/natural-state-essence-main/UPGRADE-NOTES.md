# Natural State Peptides — inquiry upgrade

This package contains the complete project with the first inquiry-flow upgrade. It is not deployed.

## Changes

- Product pages: Request COA and product inquiry actions carry the product and inquiry type into Contact.
- Contact: replaces the non-delivering form and false success message with a message composer, clipboard action, and explicit Facebook handoff. No message is sent automatically. Copy failures explain manual copying.
- Testing: a finished request-based explanation; no public COA library. Distinguishes supplier reports from Natural State-commissioned testing without inventing test coverage.
- Brand claims: removes blanket high-purity/testing assertions from the modified surfaces until supported by product-specific evidence.
- Catalog: shorter hero, result count, and Clear filters. Preserves the 15 products, strengths, inventory status, and visual identity.
- Ambassador: replaces placeholder with a partnership inquiry; no invented commission terms.

## Apply to the existing GitHub project

1. Extract this ZIP.
2. Open your natural-state-essence repository on GitHub and select the main branch.
3. From the repository root, use Add file > Upload files. Drag the extracted src folder into the upload area, preserving its folders. Do not upload the ZIP itself or the outer natural-state-essence-main folder.
4. Review the replacements before committing. Only the files listed below should differ from your downloaded version. If you have edited the same files in Lovable since exporting, reconcile those changes first.
5. Commit the update. Your connected main branch syncs to Lovable. Inspect the preview before publishing any update to the live site.

Changed source files:
- src/components/catalog-page.tsx
- src/components/site-footer.tsx
- src/data/products.ts
- src/routes/__root.tsx
- src/routes/ambassador.tsx
- src/routes/contact.tsx
- src/routes/index.tsx
- src/routes/product.$slug.tsx
- src/routes/quality.tsx

The scripts folder contains an optional verification script. Upload it at the repository root if you want to retain it.

## Validation

- Production build passed.
- TypeScript check passed.
- ESLint passed for the six primary edited files.
- Built-server checks passed: all five in-stock product COA actions resolve to the correct prefilled inquiry; invalid query parameters safely fall back; catalog still renders 15 products; homepage, catalog, testing, and ambassador routes render; partnership intent carries through.
- Browser visual QA and live clipboard behavior could not be tested in this environment.

To reproduce: install dependencies, run npm run build, npx tsc --noEmit, then node scripts/verify-inquiries.mjs.

## Check in the Lovable preview

- At phone and desktop widths, open a product and click Request COA; confirm the correct name, strength, and topic.
- Add a lot reference and question. Copy the inquiry, then paste it somewhere private to check the complete text.
- Open Facebook to confirm the existing page link. Sending requires a separate action on Facebook.
- Search and filter the catalog, then Clear filters.
- Review Quality & Testing and the partnership inquiry.

## Remaining work

The privacy and terms pages retain their original placeholder content. This update is not a legal or scientific review of existing product descriptions, storage claims, or reports. No email delivery, database, purchase system, analytics, public COAs, or commission system was added. A verified contact destination and delivery service are needed before replacing Facebook with direct form submission.
