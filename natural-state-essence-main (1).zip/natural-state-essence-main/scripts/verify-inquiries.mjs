// Run after npm run build. Exercises the built server without sending inquiries.
import assert from 'node:assert/strict';
import app from '../.output/server/index.mjs';

async function page(path, redirects = 0) {
  const response = await app.fetch(new Request(`http://localhost${path}`), {}, {
    waitUntil() {}, passThroughOnException() {},
  });
  if ([301, 302, 307, 308].includes(response.status)) {
    assert.ok(redirects < 3, 'No redirect loop');
    const target = new URL(response.headers.get('location'), 'http://localhost');
    assert.equal(target.origin, 'http://localhost');
    return page(target.pathname + target.search, redirects + 1);
  }
  assert.equal(response.status, 200, path);
  return response.text();
}
function selected(html, id) {
  const select = html.match(new RegExp(`<select[^>]*id="${id}"[^>]*>([\\s\\S]*?)</select>`));
  assert.ok(select, `Select ${id} exists`);
  return select[1].match(/<option value="([^"]*)"[^>]*selected/)?.[1];
}
for (const slug of ['retatrutide', 'epitalon', 'cjc-1295-no-dac-ipamorelin', 'pinealon', 'mots-c']) {
  const product = await page(`/product/${slug}`);
  const match = product.match(/<a[^>]*href="([^"]+)"[^>]*>Request COA<\/a>/);
  assert.ok(match, `COA action exists for ${slug}`);
  const href = match[1].replaceAll('&amp;', '&');
  const url = new URL(href, 'http://localhost');
  assert.equal(url.searchParams.get('product'), slug);
  assert.equal(url.searchParams.get('intent'), 'coa');
  const contact = await page(href);
  assert.equal(selected(contact, 'product'), slug);
  assert.equal(selected(contact, 'inquiry-topic'), 'coa');
  assert.ok(contact.includes('coa request'));
  assert.ok(contact.includes('Nothing is sent from this page.'));
  assert.ok(!contact.includes('message has been received'));
  console.log(`PASS ${slug}: product → COA → prefilled inquiry`);
}
const invalid = await page('/contact?product=unknown&intent=invalid');
assert.equal(selected(invalid, 'product'), '');
assert.equal(selected(invalid, 'inquiry-topic'), 'product');
console.log('PASS malformed query defaults');
for (const route of ['/', '/catalog', '/quality', '/ambassador']) {
  assert.ok(!(await page(route)).includes('This page is a placeholder'));
  console.log(`PASS ${route}`);
}
assert.equal((await page('/catalog')).match(/<article/g)?.length, 15);
assert.equal(selected(await page('/contact?intent=partnership'), 'inquiry-topic'), 'partnership');
console.log('PASS catalog count and partnership intent');
